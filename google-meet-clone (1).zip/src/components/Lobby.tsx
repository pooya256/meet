import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Video, VideoOff, ArrowLeft, Copy, Check } from "lucide-react";
import { motion } from "motion/react";

interface LobbyProps {
  roomId: string;
  userName: string;
  onJoin: (mic: boolean, cam: boolean) => void;
  onBack: () => void;
}

export default function Lobby({ roomId, userName, onJoin, onBack }: LobbyProps) {
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(true);
  const [copied, setCopied] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const startPreview = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        
        // Apply initial states
        stream.getAudioTracks().forEach(t => t.enabled = isMicOn);
        stream.getVideoTracks().forEach(t => t.enabled = isCamOn);
      } catch (err) {
        console.error("Error accessing media devices:", err);
      }
    };

    startPreview();

    return () => {
      streamRef.current?.getTracks().forEach(track => track.stop());
    };
  }, []);

  const toggleMic = () => {
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach(t => t.enabled = !isMicOn);
    }
    setIsMicOn(!isMicOn);
  };

  const toggleCam = () => {
    if (streamRef.current) {
      streamRef.current.getVideoTracks().forEach(t => t.enabled = !isCamOn);
    }
    setIsCamOn(!isCamOn);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(roomId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 bg-white">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        
        {/* Left Side: Video Preview */}
        <div className="space-y-6">
          <div className="relative aspect-video bg-google-gray rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-full object-cover ${!isCamOn ? "hidden" : ""}`}
            />
            {!isCamOn && (
              <div className="absolute inset-0 flex items-center justify-center bg-google-gray">
                <div className="w-24 h-24 rounded-full bg-google-blue flex items-center justify-center text-white text-4xl font-bold">
                  {userName.charAt(0).toUpperCase()}
                </div>
              </div>
            )}
            
            {/* Overlay Controls */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-4">
              <button 
                onClick={toggleMic}
                className={`p-4 rounded-full transition-all ${isMicOn ? "bg-white/20 backdrop-blur-md text-white hover:bg-white/30" : "bg-google-red text-white shadow-lg"}`}
              >
                {isMicOn ? <Mic size={24} /> : <MicOff size={24} />}
              </button>
              <button 
                onClick={toggleCam}
                className={`p-4 rounded-full transition-all ${isCamOn ? "bg-white/20 backdrop-blur-md text-white hover:bg-white/30" : "bg-google-red text-white shadow-lg"}`}
              >
                {isCamOn ? <Video size={24} /> : <VideoOff size={24} />}
              </button>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-gray-500 font-medium">آماده پیوستن هستید؟</p>
          </div>
        </div>

        {/* Right Side: Info & Action */}
        <div className="space-y-8 text-right">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-gray-500 hover:text-google-blue transition-colors mr-auto md:mr-0 ml-auto"
          >
            بازگشت
            <ArrowLeft size={20} />
          </button>

          <div className="space-y-4">
            <h2 className="text-3xl font-bold text-google-gray">جلسه آماده است</h2>
            <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 space-y-4">
              <p className="text-sm text-gray-500">کد جلسه شما:</p>
              <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-gray-200">
                <button 
                  onClick={copyCode}
                  className="text-google-blue hover:bg-blue-50 p-2 rounded-lg transition-colors"
                >
                  {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
                <span className="font-mono text-xl font-bold tracking-wider text-google-blue">{roomId}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <button 
              onClick={() => onJoin(isMicOn, isCamOn)}
              className="w-full bg-google-blue text-white py-5 rounded-2xl font-bold text-xl hover:bg-blue-600 transition-all shadow-lg hover:shadow-xl active:scale-95"
            >
              ورود به جلسه
            </button>
            <p className="text-center text-sm text-gray-400">
              شما به عنوان <span className="font-bold text-gray-600">{userName}</span> وارد می‌شوید
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
