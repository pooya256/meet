import { useState } from "react";
import { Video, Keyboard, Plus } from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import { motion } from "motion/react";

interface LandingPageProps {
  onJoin: (roomId: string, name: string) => void;
}

export default function LandingPage({ onJoin }: LandingPageProps) {
  const [inputRoomId, setInputRoomId] = useState("");
  const [userName, setUserName] = useState("");

  const handleNewMeeting = () => {
    if (!userName.trim()) {
      alert("لطفاً ابتدا نام خود را وارد کنید");
      return;
    }
    const id = uuidv4().substring(0, 12);
    onJoin(id, userName);
  };

  const handleJoinMeeting = () => {
    if (!userName.trim()) {
      alert("لطفاً ابتدا نام خود را وارد کنید");
      return;
    }
    if (inputRoomId.trim()) {
      onJoin(inputRoomId.trim(), userName);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 bg-white">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full space-y-8 text-center"
      >
        <div className="flex justify-center">
          <div className="bg-google-blue p-4 rounded-2xl text-white shadow-lg">
            <Video size={48} />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold text-google-gray">گوگل میت کلون</h1>
        
        <div className="space-y-6 bg-gray-50 p-8 rounded-3xl border border-gray-100 shadow-sm">
          {/* Option 1: Name */}
          <div className="space-y-2 text-right">
            <label className="text-sm font-medium text-gray-600 mr-1">نام شما</label>
            <input
              type="text"
              placeholder="مثلاً: علی رضایی"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-google-blue bg-white transition-all text-right"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 gap-4">
            {/* Option 2: Create */}
            <button 
              onClick={handleNewMeeting} 
              className="w-full bg-google-blue text-white py-4 rounded-xl font-bold hover:bg-blue-600 transition-all flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-95"
            >
              <Plus size={20} />
              ایجاد جلسه جدید
            </button>

            <div className="relative flex items-center py-2">
              <div className="flex-grow border-t border-gray-200"></div>
              <span className="flex-shrink mx-4 text-gray-400 text-sm">یا</span>
              <div className="flex-grow border-t border-gray-200"></div>
            </div>

            {/* Option 3: Join */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <button
                  onClick={handleJoinMeeting}
                  disabled={!inputRoomId}
                  className="bg-gray-800 text-white px-6 rounded-xl font-bold hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
                >
                  ورود
                </button>
                <div className="flex-1 flex items-center gap-2 border border-gray-200 rounded-xl px-4 py-3 bg-white focus-within:ring-2 focus-within:ring-google-blue transition-all">
                  <Keyboard size={20} className="text-gray-400" />
                  <input
                    type="text"
                    placeholder="کد جلسه را وارد کنید"
                    className="bg-transparent border-none focus:outline-none w-full text-right"
                    value={inputRoomId}
                    onChange={(e) => setInputRoomId(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
