import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { 
  Mic, MicOff, Video, VideoOff, PhoneOff, 
  MessageSquare, Users, Info, Settings, MoreVertical,
  Send, X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MeetingRoomProps {
  roomId: string;
  userName: string;
  onLeave: () => void;
  initialMic: boolean;
  initialCam: boolean;
}

interface PeerConnection {
  userId: string;
  connection: RTCPeerConnection;
  stream?: MediaStream;
}

interface ChatMessage {
  sender: string;
  message: string;
  timestamp: string;
}

export default function MeetingRoom({ roomId, userName, onLeave, initialMic, initialCam }: MeetingRoomProps) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [isMicOn, setIsMicOn] = useState(initialMic);
  const [isCamOn, setIsCamOn] = useState(initialCam);
  const [showChat, setShowChat] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [participants, setParticipants] = useState<string[]>([userName]);

  const socketRef = useRef<Socket | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const peersRef = useRef<Map<string, RTCPeerConnection>>(new Map());

  const iceServers = {
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
    ],
  };

  useEffect(() => {
    const init = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        
        // Apply initial states
        stream.getAudioTracks().forEach(track => (track.enabled = initialMic));
        stream.getVideoTracks().forEach(track => (track.enabled = initialCam));

        setLocalStream(stream);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        socketRef.current = io();
        const socket = socketRef.current;

        socket.emit("join-room", roomId, socket.id);

        socket.on("user-connected", async (userId) => {
          console.log("User connected:", userId);
          setParticipants(prev => [...prev, `User ${userId.substring(0, 4)}`]);
          const pc = createPeerConnection(userId, stream);
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          socket.emit("offer", { target: userId, sdp: pc.localDescription, sender: socket.id });
        });

        socket.on("offer", async (payload) => {
          console.log("Received offer from:", payload.sender);
          const pc = createPeerConnection(payload.sender, stream);
          await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          socket.emit("answer", { target: payload.sender, sdp: pc.localDescription, sender: socket.id });
        });

        socket.on("answer", async (payload) => {
          console.log("Received answer from:", payload.sender);
          const pc = peersRef.current.get(payload.sender);
          if (pc) {
            await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
          }
        });

        socket.on("ice-candidate", async (payload) => {
          const pc = peersRef.current.get(payload.sender);
          if (pc) {
            await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
          }
        });

        socket.on("user-disconnected", (userId) => {
          console.log("User disconnected:", userId);
          const pc = peersRef.current.get(userId);
          if (pc) pc.close();
          peersRef.current.delete(userId);
          setRemoteStreams(prev => {
            const next = new Map(prev);
            next.delete(userId);
            return next;
          });
          setParticipants(prev => prev.filter(p => !p.includes(userId.substring(0, 4))));
        });

        socket.on("chat-message", (payload) => {
          setMessages(prev => [...prev, payload]);
        });
      } catch (err) {
        console.error("Error accessing media devices:", err);
      }
    };

    init();

    return () => {
      localStream?.getTracks().forEach(track => track.stop());
      socketRef.current?.disconnect();
      peersRef.current.forEach(pc => pc.close());
    };
  }, [roomId]);

  const createPeerConnection = (userId: string, stream: MediaStream) => {
    const pc = new RTCPeerConnection(iceServers);
    peersRef.current.set(userId, pc);

    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current?.emit("ice-candidate", {
          target: userId,
          candidate: event.candidate,
          sender: socketRef.current.id,
        });
      }
    };

    pc.ontrack = (event) => {
      setRemoteStreams(prev => {
        const next = new Map(prev);
        next.set(userId, event.streams[0]);
        return next;
      });
    };

    return pc;
  };

  const toggleMic = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => (track.enabled = !isMicOn));
      setIsMicOn(!isMicOn);
    }
  };

  const toggleCam = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => (track.enabled = !isCamOn));
      setIsCamOn(!isCamOn);
    }
  };

  const sendMessage = () => {
    if (chatInput.trim() && socketRef.current) {
      socketRef.current.emit("chat-message", {
        roomId,
        sender: userName,
        message: chatInput,
      });
      setChatInput("");
    }
  };

  return (
    <div className="flex-1 bg-black flex flex-col overflow-hidden relative">
      {/* Header */}
      <div className="absolute top-4 left-4 z-10 text-white flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-lg backdrop-blur-md">
        <span className="font-medium">{roomId}</span>
        <div className="w-1 h-1 bg-white/40 rounded-full" />
        <span className="text-sm text-white/80">{userName}</span>
      </div>

      {/* Video Grid */}
      <div className="flex-1 p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 auto-rows-fr overflow-y-auto">
        {/* Local Video */}
        <div className="relative rounded-xl overflow-hidden bg-google-gray aspect-video shadow-2xl">
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className={`w-full h-full object-cover ${!isCamOn ? "hidden" : ""}`}
          />
          {!isCamOn && (
            <div className="absolute inset-0 flex items-center justify-center bg-google-gray">
              <div className="w-20 h-20 rounded-full bg-google-blue flex items-center justify-center text-white text-3xl font-bold">
                {userName.charAt(0).toUpperCase()}
              </div>
            </div>
          )}
          <div className="absolute bottom-4 left-4 bg-black/40 px-3 py-1 rounded text-white text-sm backdrop-blur-sm">
            You {isMicOn ? "" : "(Muted)"}
          </div>
        </div>

        {/* Remote Videos */}
        {Array.from(remoteStreams.entries()).map(([id, s]) => (
          <RemoteVideo key={id} stream={s} userId={id} />
        ))}
      </div>

      {/* Controls */}
      <div className="bg-black p-4 flex items-center justify-between">
        <div className="hidden md:flex items-center gap-4 text-white">
          <div className="flex flex-col">
            <span className="text-sm font-medium">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <span className="text-xs text-gray-400">Meeting details</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={toggleMic}
            className={isMicOn ? "control-btn" : "control-btn-active"}
          >
            {isMicOn ? <Mic size={20} /> : <MicOff size={20} />}
          </button>
          <button 
            onClick={toggleCam}
            className={isCamOn ? "control-btn" : "control-btn-active"}
          >
            {isCamOn ? <Video size={20} /> : <VideoOff size={20} />}
          </button>
          <button 
            onClick={onLeave}
            className="p-3 rounded-full bg-google-red text-white hover:bg-red-600 transition-colors w-16 flex justify-center"
          >
            <PhoneOff size={20} />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowChat(!showChat)}
            className={`p-3 rounded-full transition-colors ${showChat ? "bg-google-blue text-white" : "text-white hover:bg-white/10"}`}
          >
            <MessageSquare size={20} />
          </button>
          <button className="p-3 rounded-full text-white hover:bg-white/10">
            <Users size={20} />
          </button>
          <button className="p-3 rounded-full text-white hover:bg-white/10 hidden md:block">
            <Info size={20} />
          </button>
        </div>
      </div>

      {/* Chat Sidebar */}
      <AnimatePresence>
        {showChat && (
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute top-0 right-0 h-full w-full md:w-96 bg-white shadow-2xl z-50 flex flex-col"
          >
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="text-lg font-medium">In-call messages</h2>
              <button onClick={() => setShowChat(false)} className="p-2 hover:bg-gray-100 rounded-full">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="bg-blue-50 p-3 rounded-lg text-xs text-blue-700">
                Messages can only be seen by people in the call and are deleted when the call ends.
              </div>
              {messages.map((msg, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{msg.sender}</span>
                    <span className="text-[10px] text-gray-400">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">{msg.message}</p>
                </div>
              ))}
            </div>

            <div className="p-4 border-t flex items-center gap-2">
              <input
                type="text"
                placeholder="Send a message"
                className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-google-blue"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              />
              <button 
                onClick={sendMessage}
                disabled={!chatInput.trim()}
                className="p-2 text-google-blue disabled:opacity-50"
              >
                <Send size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function RemoteVideo({ stream, userId }: { stream: MediaStream; userId: string; key?: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className="relative rounded-xl overflow-hidden bg-google-gray aspect-video shadow-lg">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />
      <div className="absolute bottom-4 left-4 bg-black/40 px-3 py-1 rounded text-white text-sm backdrop-blur-sm">
        User {userId.substring(0, 4)}
      </div>
    </div>
  );
}
