/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import LandingPage from "./components/LandingPage";
import Lobby from "./components/Lobby";
import MeetingRoom from "./components/MeetingRoom";

enum AppState {
  LANDING,
  LOBBY,
  MEETING
}

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.LANDING);
  const [roomId, setRoomId] = useState<string>("");
  const [userName, setUserName] = useState<string>("");
  const [initialMic, setInitialMic] = useState(true);
  const [initialCam, setInitialCam] = useState(true);

  useEffect(() => {
    const path = window.location.pathname.split("/")[1];
    if (path && path.length > 5) {
      setRoomId(path);
      setAppState(AppState.LOBBY);
    }
  }, []);

  const handleStartLobby = (id: string, name: string) => {
    setRoomId(id);
    setUserName(name);
    setAppState(AppState.LOBBY);
    window.history.pushState({}, "", `/${id}`);
  };

  const handleJoinMeeting = (mic: boolean, cam: boolean) => {
    setInitialMic(mic);
    setInitialCam(cam);
    setAppState(AppState.MEETING);
  };

  const leaveMeeting = () => {
    setAppState(AppState.LANDING);
    setRoomId("");
    window.history.pushState({}, "", "/");
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {appState === AppState.LANDING && (
        <LandingPage onJoin={handleStartLobby} />
      )}
      
      {appState === AppState.LOBBY && (
        <Lobby 
          roomId={roomId} 
          userName={userName} 
          onJoin={handleJoinMeeting}
          onBack={() => setAppState(AppState.LANDING)}
        />
      )}

      {appState === AppState.MEETING && (
        <MeetingRoom 
          roomId={roomId} 
          userName={userName} 
          onLeave={leaveMeeting}
          initialMic={initialMic}
          initialCam={initialCam}
        />
      )}
    </div>
  );
}


